Пример демонстрирует создание AOP приложения. Разбираем Advice:
AfterReturning
